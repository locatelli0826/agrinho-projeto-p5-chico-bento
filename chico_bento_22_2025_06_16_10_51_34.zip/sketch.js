function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}let chicoX;
let chicoY;
let movimentoChico;
let velocidadeChico = 1;

let nuvem1X;
let nuvem2X;
let velocidadeNuvem1 = 0.2;
let velocidadeNuvem2 = 0.3;

function setup() {
  createCanvas(600, 450); // Mantém o canvas maior para o cenário da fazenda
  // O background será desenhado em draw()
  // noLoop(); // Removido, pois a animação do Chico Bento e nuvens precisa de loop
  chicoX = width / 2; // Centraliza o Chico Bento horizontalmente
  chicoY = height * 0.65;
  movimentoChico = 0;

  nuvem1X = width * 0.1;
  nuvem2X = width * 0.6;
}

function draw() {
  // --- Fundo da Fazenda Animado ---
  background(102, 204, 0); // Verde para a grama
  fill(139, 69, 19); // Marrom para a terra
  rect(0, height * 0.7, width, height * 0.3);

  // Céu azul claro
  fill(135, 206, 235);
  rect(0, 0, width, height * 0.7);

  // Sol amarelo
  fill(255, 255, 0);
  ellipse(width * 0.85, height * 0.15, 80, 80);

  // Nuvens animadas
  fill(255);
  ellipse(nuvem1X, height * 0.2, 100, 60);
  ellipse(nuvem1X + 30, height * 0.18, 80, 50);
  ellipse(nuvem2X, height * 0.3, 120, 70);
  ellipse(nuvem2X + 40, height * 0.28, 90, 55);

  nuvem1X += velocidadeNuvem1;
  nuvem2X += velocidadeNuvem2;

  if (nuvem1X > width + 50) {
    nuvem1X = -150;
  }
  if (nuvem2X > width + 50) {
    nuvem2X = -150;
  }

  // Montanhas ao longe (tons de verde)
  fill(0, 128, 0);
  triangle(width * 0.1, height * 0.65, width * 0.25, height * 0.45, width * 0.4, height * 0.65);
  fill(34, 139, 34);
  triangle(width * 0.6, height * 0.7, width * 0.75, height * 0.55, width * 0.9, height * 0.7);

  // --- Desenhar uma cerca de madeira (Movido para cá para ficar atrás do Chico Bento) ---
  fill(139, 69, 19); // Cor marrom para a madeira
  stroke(0); // Borda preta
  strokeWeight(2);
  for (let i = 0; i < width; i += 50) { // Cria postes a cada 50 pixels
    rect(i, height * 0.65, 10, 40); // Postes verticais
  }
  rect(0, height * 0.68, width, 10); // Tábua horizontal de baixo
  rect(0, height * 0.63, width, 10); // Tábua horizontal de cima
  noStroke(); // Remove a borda para os próximos desenhos

  // --- Desenho da Torre 5G (adicionado aqui) ---
  push(); // Salva o estado atual das transformações e estilos

  // Posiciona a torre no canto superior direito do cenário da fazenda
  // Ajuste estes valores para mover a torre no cenário
  translate(width * 0.85, height * 0.7); // Move o ponto de origem para a base da torre
  scale(0.5); // Reduz o tamanho da torre para que ela se encaixe melhor no cenário

  let towerBaseX_tower = 0; // A base da torre agora é 0,0 devido ao translate
  let towerBaseY_tower = 0; // A base da torre agora é 0,0 devido ao translate

  // Desenha a base da torre
  fill(0); // Define a cor de preenchimento para preto
  rectMode(CENTER); // Desenha retângulos a partir do seu centro
  rect(towerBaseX_tower, towerBaseY_tower, 60, 20); // Retângulo da base

  // Desenha a estrutura principal da torre
  stroke(0); // Define a cor da linha para preto
  strokeWeight(5); // Define a espessura da linha
  line(towerBaseX_tower - 25, towerBaseY_tower, towerBaseX_tower - 5, towerBaseY_tower - 180); // Perna esquerda
  line(towerBaseX_tower + 25, towerBaseY_tower, towerBaseX_tower + 5, towerBaseY_tower - 180); // Perna direita
  line(towerBaseX_tower - 5, towerBaseY_tower - 180, towerBaseX_tower + 5, towerBaseY_tower - 180); // Linha horizontal superior

  // Desenha as vigas transversais para a torre
  strokeWeight(2); // Linhas mais finas para as vigas transversais
  line(towerBaseX_tower - 20, towerBaseY_tower - 40, towerBaseX_tower + 20, towerBaseY_tower - 40);
  line(towerBaseX_tower - 15, towerBaseY_tower - 80, towerBaseX_tower + 15, towerBaseY_tower - 80);
  line(towerBaseX_tower - 10, towerBaseY_tower - 120, towerBaseX_tower + 10, towerBaseY_tower - 120);

  line(towerBaseX_tower - 25, towerBaseY_tower, towerBaseX_tower, towerBaseY_tower - 40);
  line(towerBaseX_tower + 25, towerBaseY_tower, towerBaseX_tower, towerBaseY_tower - 40);

  line(towerBaseX_tower - 20, towerBaseY_tower - 40, towerBaseX_tower, towerBaseY_tower - 80);
  line(towerBaseX_tower + 20, towerBaseY_tower - 40, towerBaseX_tower, towerBaseY_tower - 80);

  line(towerBaseX_tower - 15, towerBaseY_tower - 80, towerBaseX_tower, towerBaseY_tower - 120);
  line(towerBaseX_tower + 15, towerBaseY_tower - 80, towerBaseX_tower, towerBaseY_tower - 120);

  // Desenha a antena/transmissor no topo
  let antennaX_tower = towerBaseX_tower;
  let antennaY_tower = towerBaseY_tower - 180;
  strokeWeight(5);
  point(antennaX_tower, antennaY_tower); // O ponto central da antena

  // Desenha as ondas de sinal sem fio
  noFill(); // Sem preenchimento para as ondas
  strokeWeight(3); // Espessura maior para as ondas

  // Primeira onda (metade superior)
  arc(antennaX_tower, antennaY_tower + 20, 80, 40, PI, TWO_PI); // Onda externa (metade superior de uma elipse)
  arc(antennaX_tower, antennaY_tower + 20, 40, 20, PI, TWO_PI); // Onda interna (metade superior de uma elipse)

  // Segunda onda (espelhada horizontalmente)
  arc(antennaX_tower, antennaY_tower + 20, 80, 40, 0, PI); // Onda externa (metade inferior de uma elipse)
  arc(antennaX_tower, antennaY_tower + 20, 40, 20, 0, PI); // Onda interna (metade inferior de uma elipse)

  pop(); // Restaura o estado anterior (desfaz as transformações e estilos da torre)

  // --- Chico Bento Animado ---
  push(); // Salva o sistema de coordenadas atual
  translate(chicoX, chicoY + sin(frameCount * 0.05) * 3); // Pequeno movimento vertical suave

  // Rotação suave do corpo (menos intensa)
  rotate(sin(frameCount * 0.03) * 0.03);

  // Cabeça
  fill(245, 222, 179); // Cor de pele
  ellipse(0, -60 * 0.8, 130 * 0.8, 140 * 0.8);

  // Cabelo
  fill(255, 215, 0); // Amarelo mais claro
  stroke(0); // Adiciona contorno para o cabelo para garantir visibilidade
  strokeWeight(1); // Define a espessura do contorno
  curve(-60 * 0.8, -90 * 0.8, -30 * 0.8, -100 * 0.8, 10 * 0.8, -100 * 0.8, 40 * 0.8, -90 * 0.8); // Linha 104
  curve(-50 * 0.8, -95 * 0.8, -20 * 0.8, -105 * 0.8, 0 * 0.8, -105 * 0.8, 30 * 0.8, -95 * 0.8);
  curve(-40 * 0.8, -100 * 0.8, -10 * 0.8, -110 * 0.8, -10 * 0.8, -110 * 0.8, 20 * 0.8, -100 * 0.8);
  curve(-30 * 0.8, -95 * 0.8, 0 * 0.8, -105 * 0.8, -20 * 0.8, -105 * 0.8, 10 * 0.8, -95 * 0.8);
  curve(-20 * 0.8, -90 * 0.8, 10 * 0.8, -100 * 0.8, -30 * 0.8, -100 * 0.8, 0 * 0.8, -90 * 0.8); // Linha 108
  noStroke(); // Remove o contorno após desenhar o cabelo

  // Chapéu fixo na cabeça - Ajustado para cima
  fill(139, 69, 19); // Marrom // Linha 109
  stroke(0); // Adiciona contorno para o chapéu
  strokeWeight(1); // Define a espessura do contorno
  ellipse(0, -95 * 0.8, 150 * 0.8, 40 * 0.8); // Aba (subi 10) // Linha 110
  rect(-75 * 0.8, -115 * 0.8, 150 * 0.8, 30 * 0.8); // Parte superior (subi 10) // Linha 111
  noStroke(); // Remove o contorno após desenhar o chapéu

  // Olhos // Linha 112 (Este é um comentário e não causa erro de execução)
  fill(255);
  ellipse(-25 * 0.8, -60 * 0.8, 25 * 0.8, 30 * 0.8);
  ellipse(25 * 0.8, -60 * 0.8, 25 * 0.8, 30 * 0.8);
  fill(0);
  ellipse(-25 * 0.8, -58 * 0.8, 10 * 0.8, 10 * 0.8);
  ellipse(25 * 0.8, -58 * 0.8, 10 * 0.8, 10 * 0.8);

  // Boca
  fill(255, 0, 0);
  arc(0, -30 * 0.8, 50 * 0.8, 30 * 0.8, 0, PI);
  fill(0);
  arc(0, -30 * 0.8, 50 * 0.8, 30 * 0.8, 0, 0.1); // Linha inferior da boca

  // Nariz
  fill(139, 69, 19);
  ellipse(0, -45 * 0.8, 15 * 0.8, 12 * 0.8);

  // Corpo
  fill(255, 255, 0); // Amarelo da camiseta
  rect(-40 * 0.8, 0 * 0.8, 80 * 0.8, 80 * 0.8, 10 * 0.8); // Cantos arredondados

  // Braço esquerdo (segurando o celular) - Balançando um pouco
  fill(245, 222, 179);
  rect(-70 * 0.8 + sin(frameCount * 0.08) * 2, 10 * 0.8 + cos(frameCount * 0.08) * 2, 30 * 0.8, 60 * 0.8, 5 * 0.8);
  // Mão esquerda (segurando o celular) - Balançando um pouco
  ellipse(-55 * 0.8 + sin(frameCount * 0.08) * 2, 70 * 0.8 + cos(frameCount * 0.08) * 2, 30 * 0.8, 20 * 0.8);

  // Celular na mão esquerda - Acompanha o movimento da mão
  fill(80); // Cor cinza escura do celular
  rect(-65 * 0.8 + sin(frameCount * 0.08) * 2, 55 * 0.8 + cos(frameCount * 0.08) * 2, 20 * 0.8, 40 * 0.8, 5 * 0.8);
  fill(220); // Tela do celular
  rect(-63 * 0.8 + sin(frameCount * 0.08) * 2, 57 * 0.8 + cos(frameCount * 0.08) * 2, 16 * 0.8, 36 * 0.8, 3 * 0.8);

  // Braço direito - Balançando um pouco (em fase diferente)
  fill(245, 222, 179);
  rect(40 * 0.8 + sin(frameCount * 0.08 + PI * 0.5) * 2, 10 * 0.8 + cos(frameCount * 0.08 + PI * 0.5) * 2, 30 * 0.8, 60 * 0.8, 5 * 0.8);
  // Mão direita - Balançando um pouco (em fase diferente)
  ellipse(55 * 0.8 + sin(frameCount * 0.08 + PI * 0.5) * 2, 70 * 0.8 + cos(frameCount * 0.08 + PI * 0.5) * 2, 30 * 0.8, 20 * 0.8);

  // Calças
  fill(0, 128, 255); // Azul
  rect(-50 * 0.8, 80 * 0.8, 100 * 0.8, 60 * 0.8);

  // Padrão da Calça (xadrez simples)
  stroke(0);
  strokeWeight(2 * 0.8);
  line(-50 * 0.8, 100 * 0.8, 50 * 0.8, 100 * 0.8);
  line(-50 * 0.8, 120 * 0.8, 50 * 0.8, 120 * 0.8);
  line(-25 * 0.8, 80 * 0.8, -25 * 0.8, 140 * 0.8);
  line(25 * 0.8, 80 * 0.8, 25 * 0.8, 140 * 0.8);
  noStroke();
  strokeWeight(1);

  // Pernas animadas
  push();
  translate(0, sin(frameCount * 0.1) * 3); // Pequeno movimento vertical das pernas
  fill(139, 69, 19);
  ellipse(-20 * 0.8, 170 * 0.8, 50 * 0.8, 25 * 0.8); // Pé esquerdo
  ellipse(30 * 0.8, 170 * 0.8, 50 * 0.8, 25 * 0.8); // Pé direito
  rect(-45 * 0.8, 150 * 0.8, 50 * 0.8, 30 * 0.8, 5 * 0.8); // Bota esquerda
  rect(5 * 0.8, 150 * 0.8, 50 * 0.8, 30 * 0.8, 5 * 0.8); // Bota direita
  pop();

  // Detalhes da Bota (linhas) - Acompanham o movimento das pernas
  stroke(0);
  strokeWeight(2 * 0.8);
  line(-35 * 0.8, 155 * 0.8 + sin(frameCount * 0.1) * 3, -35 * 0.8, 175 * 0.8 + sin(frameCount * 0.1) * 3);
  line(-10 * 0.8, 155 * 0.8 + sin(frameCount * 0.1) * 3, -10 * 0.8, 175 * 0.8 + sin(frameCount * 0.1) * 3);
  line(15 * 0.8, 155 * 0.8 + sin(frameCount * 0.1) * 3, 15 * 0.8, 175 * 0.8 + sin(frameCount * 0.1) * 3);
  line(40 * 0.8, 155 * 0.8 + sin(frameCount * 0.1) * 3, 40 * 0.8, 175 * 0.8 + sin(frameCount * 0.1) * 3);
  noStroke();
  strokeWeight(1);

  pop(); // Restaura o sistema de coordenadas anterior (do push() lá em cima para o Chico Bento)

  // --- Outros elementos adicionados anteriormente ---

  // Desenhar uma árvore simples
  fill(139, 69, 19); // Tronco marrom
  rect(width * 0.15, height * 0.5, 30, 80); // Tronco
  fill(34, 139, 34); // Folhas verdes
  ellipse(width * 0.15 + 15, height * 0.45, 80, 80); // Copa da árvore
  ellipse(width * 0.15 - 10, height * 0.48, 60, 60);
  ellipse(width * 0.15 + 40, height * 0.48, 60, 60);

  // Adicionar um diálogo (texto) sobre a cabeça do Chico Bento
  // Primeiro, desenhe uma "bolha de fala"
  fill(255); // Branco para a bolha
  triangle(chicoX + 30, chicoY - 140, chicoX + 50, chicoY - 120, chicoX + 40, chicoY - 100); // Ponta da bolha
  rect(chicoX - 70, chicoY - 180, 160, 60, 10); // Corpo da bolha arredondada

  // Depois, adicione o texto dentro da bolha
  fill(0); // Cor do texto (preto)
  textSize(14); // Tamanho da fonte
  textAlign(CENTER, CENTER); // Alinhar o texto ao centro da bolha
  text("Pegou sinal!", chicoX, chicoY - 150); // Texto e posição

  // Adicionar um cachorro no canto inferior direito
  let cachorroX = width * 0.85;
  let cachorroY = height * 0.85;

  fill(160, 82, 45); // Cor do cachorro (marrom claro)
  ellipse(cachorroX, cachorroY, 80, 50); // Corpo
  ellipse(cachorroX - 30, cachorroY - 20, 40, 30); // Cabeça
  fill(0); // Olho
  ellipse(cachorroX - 40, cachorroY - 25, 5, 5);
  fill(160, 82, 45); // Orelha
  triangle(cachorroX - 20, cachorroY - 25, cachorroX - 5, cachorroY - 45, cachorroX + 5, cachorroY - 25);
  fill(139, 69, 19); // Nariz
  ellipse(cachorroX - 45, cachorroY - 20, 5, 3);
  fill(160, 82, 45); // Pata dianteira
  rect(cachorroX - 25, cachorroY + 15, 10, 20);
  rect(cachorroX + 15, cachorroY + 15, 10, 20);
  fill(139, 69, 19); // Cauda
  stroke(0); // Adiciona um contorno preto para a cauda
  strokeWeight(1); // Define a espessura do contorno
  arc(cachorroX + 40, cachorroY, 20, 40, PI + QUARTER_PI, TWO_PI); // Cauda curvada
  noStroke(); // Remove o contorno para os próximos desenhos
}
